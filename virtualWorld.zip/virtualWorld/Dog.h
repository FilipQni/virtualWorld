#pragma once
#include "Animal.h"

class Dog : public Animal
{
public:
	Dog(World& ref);
	Dog(World& ref, int strength_, int agility_, int age_, char symbol_, string name_, bool isAlive_, bool didMove_, bool extraMove_);
	Organism* getClass();
	void nextPosition(nextPositionStruct& nextPosition_);\
	void collision(nextPositionStruct& nextPosition_, vector<Organism*>& organismVector);
	~Dog();
};

