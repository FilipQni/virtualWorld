#include "Animal.h"
#include "World.h"


Animal::Animal(World& wordReference_, int strength_, int agility_, int age_, char symbol_, string name_, bool isAlive_, bool didMove_, bool extraTurn_)
	:Organism(wordReference_, strength_, agility_, age_, symbol_, name_, isAlive_, didMove_, extraTurn_)
{

}

void Animal::action(Organism* mapArray[20][20], vector<Organism*>& organismVector, int i)
{
	nextPositionStruct nextPosition_;
	nextPosition(nextPosition_);
	//empty field
	if (mapArray[nextPosition_.positionX][nextPosition_.positionY] == nullptr) {
		mapArray[positionX][positionY] = nullptr;
		setPositionX(nextPosition_.positionX);
		setPositionY(nextPosition_.positionY);
		setDidMove(true);
	}
	else {
		string actionLog;

		//if it the same type of an animal
		if (symbol == mapArray[nextPosition_.positionX][nextPosition_.positionY]->getSymbol()) {
			if (isEmptyFieldAround(nextPosition_, mapArray)) {
				collision(nextPosition_, organismVector);
				setDidMove(true);
			}
		}
		else {
			//there is a weaker unit
			if (strength >= mapArray[nextPosition_.positionX][nextPosition_.positionY]->getStrength()) {
				int j;
				for (j = 0; j < organismVector.size(); j++) {
					if (organismVector[j]->getPositionX() == nextPosition_.positionX && organismVector[j]->getPositionY() == nextPosition_.positionY) break;
				}
				organismVector[j]->setIsAlive(false);
				if (organismVector[j]->getSymbol() == 'C') setExtraMove(true);
				if (organismVector[j]->getSymbol() == 'G') setStrength(getStrength() + 1);
				setPositionX(nextPosition_.positionX);
				setPositionY(nextPosition_.positionY);
				setDidMove(true);
				actionLog =
					+"A "
					+ getName()
					+ " ate the "
					+ mapArray[nextPosition_.positionX][nextPosition_.positionY]->getName()
					+ " at ("
					+ std::to_string(nextPosition_.positionX + 1)
					+ ","
					+ std::to_string(nextPosition_.positionY + 1)
					+ ")";
				worldReference.addToTurnLog(actionLog);
			}
			//there is a stronger unit
			if (strength < mapArray[nextPosition_.positionX][nextPosition_.positionY]->getStrength()) {
				setIsAlive(false);
				setDidMove(true);
				actionLog =
					+ "A "
					+ getName()
					+ " died from the "
					+ mapArray[nextPosition_.positionX][nextPosition_.positionY]->getName()
					+ " at ("
					+ std::to_string(nextPosition_.positionX + 1)
					+ ","
					+ std::to_string(nextPosition_.positionY + 1)
					+ ")";
				worldReference.addToTurnLog(actionLog);
			}
		}
	}
}

void Animal::nextPosition(nextPositionStruct& nextPosition_)
{

	random_device dev;
	mt19937 rng(dev());
	uniform_int_distribution<mt19937::result_type> dist(0, 7);

	nextPosition_.positionX = getPositionX();
	nextPosition_.positionY = getPositionX();
	int changePosition = dist(rng);
	int changeX, changeY;
	do {
		changePosition = dist(rng);
		//	|0|1|2|
		switch (changePosition)							        //	|3|x|4|
		{												        //	|5|6|7|
		case 0:
			changeX = -1;
			changeY = 1;
			break;
		case 1:
			changeX = 0;
			changeY = 1;
			break;
		case 2:
			changeX = 1;
			changeY = 1;
			break;
		case 3:
			changeX = -1;
			changeY = 0;
			break;
		case 4:
			changeX = 1;
			changeY = 0;
			break;
		case 5:
			changeX = -1;
			changeY = -1;
			break;
		case 6:
			changeX = 0;
			changeY = -1;
			break;
		case 7:
			changeX = 1;
			changeY = -1;
			break;
		}
	} while (positionX + changeX < 0 || positionX + changeX > 19 || positionY + changeY < 0 || positionY + changeY > 19);
	nextPosition_.positionX = getPositionX() + changeX;
	nextPosition_.positionY = getPositionY() + changeY;
}

bool Animal::isEmptyFieldAround(nextPositionStruct& nextPosition_, Organism* mapArray[20][20]) {
	/*
			|7|8|1|
			|6|X|2|   <- pokolei sprawdza te pola, je�eli jakie� jest wolne to funkcja wychodzi, struktura posiada wspolrzedne wolnego pola
			|5|4|3|
	*/
	nextPosition_.positionX = getPositionX();
	nextPosition_.positionY = getPositionY();

	nextPosition_.positionX += 1;
	nextPosition_.positionY += 1;
	if (positionsCheck(nextPosition_, mapArray)) return true;

	nextPosition_.positionY += 1;
	if (positionsCheck(nextPosition_, mapArray)) return true;

	nextPosition_.positionY += 1;
	if (positionsCheck(nextPosition_, mapArray)) return true;

	nextPosition_.positionX -= 1;
	if (positionsCheck(nextPosition_, mapArray)) return true;

	nextPosition_.positionX -= 1;
	if (positionsCheck(nextPosition_, mapArray)) return true;

	nextPosition_.positionY -= 1;
	if (positionsCheck(nextPosition_, mapArray)) return true;

	nextPosition_.positionY -= 1;
	if (positionsCheck(nextPosition_, mapArray)) return true;

	nextPosition_.positionX += 1;
	if (positionsCheck(nextPosition_, mapArray)) return true;

	return false;
}

bool Animal::positionsCheck(nextPositionStruct& nextPosition_, Organism* mapArray[20][20]) {

	if (nextPosition_.positionX >= 0 && nextPosition_.positionX <= 19 && nextPosition_.positionY >= 0 && nextPosition_.positionY <= 19
		&& mapArray[nextPosition_.positionX][nextPosition_.positionY] == nullptr) return true;
	return false;
}

void Animal::collision(nextPositionStruct& nextPosition_, vector<Organism*>& organismVector)
{
	string actionLog;
	setDidMove(true);
	organismVector.push_back(getClass());
	organismVector.back()->setPositionX(nextPosition_.positionX);
	organismVector.back()->setPositionY(nextPosition_.positionY);
	organismVector.back()->setDidMove(true);
	actionLog =
		+"A "
		+ getName()
		+ " was born at "
		+ std::to_string(nextPosition_.positionX + 1)
		+ ","
		+ std::to_string(nextPosition_.positionY + 1)
		+ ")";
	worldReference.addToTurnLog(actionLog);
}

Animal::~Animal()
{
}
