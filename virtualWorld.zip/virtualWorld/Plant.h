#pragma once
#include "Organism.h"

class Plant : public Organism
{
public:
	Plant(World& wordReference_, int strength_, int agility_, int age_, char symbol_, string name_, bool isAlive_, bool didMove_, bool extraTurn_);
	void action(Organism* mapArray[20][20], vector<Organism*>& organismVector, int i);
	virtual bool nextPosition(nextPositionStruct& nextPosition_, Organism* mapArray[20][20]);
	virtual bool positionsCheck(nextPositionStruct& nextPosition_, Organism* mapArray[20][20]);
	virtual void collision();
	~Plant();
};

