#include "Dog.h"

Dog::Dog(World& ref)
	:Animal(ref, 6, 6, 0, 'D', "Dog", true, true, false)
{
}

Dog::Dog(World& ref, int strength_, int agility_, int age_, char symbol_, string name_, bool isAlive_, bool didMove_, bool extraMove_)
	:Animal(ref, strength_, agility_, age_, symbol_, name_, isAlive_, didMove_, extraMove_)
{
}

Organism* Dog::getClass()
{
	Organism* org = new Dog(worldReference);
	return org;
}

void Dog::nextPosition(nextPositionStruct& nextPosition_)
{

	random_device dev;
	mt19937 rng(dev());
	uniform_int_distribution<mt19937::result_type> dist(0, 23);

	nextPosition_.positionX = getPositionX();
	nextPosition_.positionY = getPositionX();
	int changePosition = dist(rng);
	int changeX, changeY;
	do {
		changePosition = dist(rng);
		//cout << changePosition << " <- LOSOWY CASE " << endl; //	| 0| 1| 2| 3| 4|
		switch (changePosition)							        //	| 5| 6| 7| 8| 9|
		{														//	|10|11| x|12|13|
																//	|14|15|16|17|18|
		case 0:													//	|19|20|21|22|23|
			changeX = -2;										
			changeY = -2;										
			break;
		case 1:													
			changeX = -1;										
			changeY = -2;
			break;
		case 2:													
			changeX = 0;										
			changeY = -2;
			break;
		case 3:
			changeX = 1;
			changeY = -2;
			break;
		case 4:
			changeX = 2;
			changeY = -2;
			break;
		case 5:
			changeX = -2;
			changeY = -1;
			break;
		case 6:
			changeX = -1;
			changeY = -1;
			break;
		case 7:
			changeX = 0;
			changeY = -1;
			break;
		case 8:
			changeX = 1;
			changeY = -1;
			break;
		case 9:
			changeX = 2;
			changeY = -1;
			break;
		case 10:
			changeX = -2;
			changeY = 0;
			break;
		case 11:
			changeX = -1;
			changeY = 0;
			break;
		case 12:
			changeX = 1;
			changeY = 0;
			break;
		case 13:
			changeX = 2;
			changeY = 0;
			break;
		case 14:
			changeX = -2;
			changeY = 1;
			break;
		case 15:
			changeX = -1;
			changeY = 1;
			break;
		case 16:
			changeX = 0;
			changeY = 1;
			break;
		case 17:
			changeX = 1;
			changeY = 1;
			break;
		case 18:
			changeX = 2;
			changeY = 1;
			break;
		case 19:
			changeX = -2;
			changeY = 2;
			break;
		case 20:
			changeX = -1;
			changeY = 2;
			break;
		case 21:
			changeX = 0;
			changeY = 2;
			break;
		case 22:
			changeX = 1;
			changeY = 2;
			break;
		case 23:
			changeX = 2;
			changeY = 2;
			break;


		}
	} while (positionX + changeX < 0 || positionX + changeX > 19 || positionY + changeY < 0 || positionY + changeY > 19);
	nextPosition_.positionX = getPositionX() + changeX;
	nextPosition_.positionY = getPositionY() + changeY;
}

void Dog::collision(nextPositionStruct& nextPosition_, vector<Organism*>& organismVector)
{
	Animal::collision(nextPosition_, organismVector);
	strength++;
}

Dog::~Dog()
{
}
