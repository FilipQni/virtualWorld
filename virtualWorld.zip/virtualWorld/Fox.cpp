#include "Fox.h"

Fox::Fox(World& ref)
	:Animal(ref, 3, 7, 0, 'F', "Fox",true, true, false)
{
}

Fox::Fox(World& ref, int strength_, int agility_, int age_, char symbol_, string name_, bool isAlive_, bool didMove_, bool extraMove_)
	: Animal(ref, strength_, agility_, age_, symbol_, name_, isAlive_, didMove_, extraMove_)
{
}

Organism* Fox::getClass()
{
	Organism* org = new Fox(worldReference);
	return org;
}

void Fox::action(Organism* mapArray[20][20], vector<Organism*>& organismVector, int i)
{
	nextPositionStruct nextPosition_;
	nextPosition(nextPosition_);
	//puste pole
	if (mapArray[nextPosition_.positionX][nextPosition_.positionY] == nullptr) {
		mapArray[positionX][positionY] = nullptr;
		setPositionX(nextPosition_.positionX);
		setPositionY(nextPosition_.positionY);
		setDidMove(true);
	}
	else {
		//jak ten sam rodzaj
		if (symbol == mapArray[nextPosition_.positionX][nextPosition_.positionY]->getSymbol()) {
			if (isEmptyFieldAround(nextPosition_, mapArray)) {
				collision(nextPosition_, organismVector);
				setDidMove(true);
			}
		}
		else {
			//pole zajete przez jednostke slabsza
			if (strength >= mapArray[nextPosition_.positionX][nextPosition_.positionY]->getStrength()) {
				int j;
				for (j = 0; j < organismVector.size(); j++) {
					if (organismVector[j]->getPositionX() == nextPosition_.positionX && organismVector[j]->getPositionY() == nextPosition_.positionY) break;
				}
				organismVector[j]->setIsAlive(false);
				setPositionX(nextPosition_.positionX);
				setPositionY(nextPosition_.positionY);
				setDidMove(true);
				cout << getName() << " ate " << mapArray[nextPosition_.positionX][nextPosition_.positionY]->getName() << " at ( " << positionX << "," << positionY << " )" << endl;
			}
			//pole zajete przez jednostke silniejsza
			if (strength < mapArray[nextPosition_.positionX][nextPosition_.positionY]->getStrength()) {
				setDidMove(true);
				cout << getName() << " avoided death from " << mapArray[nextPosition_.positionX][nextPosition_.positionY]->getName() << " at ( " << nextPosition_.positionX << "," << nextPosition_.positionY << " )" << endl;
			}
		}
	}
}

Fox::~Fox()
{
}
