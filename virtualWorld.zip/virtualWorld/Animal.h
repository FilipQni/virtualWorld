#pragma once
#include "Organism.h"

class Animal : public Organism
{
public:
	Animal (World& wordReference_, int strength_, int agility_, int age_, char symbol_, string name_, bool isAlive_, bool didMove_, bool extraMove_);
	virtual void action(Organism* mapArray[20][20], vector<Organism*>& organismVector, int i);
	virtual void nextPosition(nextPositionStruct& nextPosition_);
	virtual bool isEmptyFieldAround(nextPositionStruct& nextPosition_, Organism* mapArray[20][20]);
	virtual bool positionsCheck(nextPositionStruct& nextPosition_, Organism* mapArray[20][20]);
	virtual void collision(nextPositionStruct& nextPosition_, vector<Organism*>& organismVector);
	~Animal();
};


