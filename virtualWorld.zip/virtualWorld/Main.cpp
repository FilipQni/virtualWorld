#include <iostream>
#include "World.h"

using namespace std;

int main(int argc, char** argv) {
	return 0;
}