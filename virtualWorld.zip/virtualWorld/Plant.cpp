#include "Plant.h"
#include "World.h"

Plant::Plant(World& wordReference_, int strength_, int agility_, int age_, char symbol_, string name_, bool isAlive_, bool didMove_, bool extraTurn_)
	:Organism(wordReference_, strength_, agility_, age_, symbol_, name_, isAlive_, didMove_, extraTurn_)
{

}

void Plant::action(Organism* mapArray[20][20], vector<Organism*>& organismVector, int i)
{
	random_device dev;
	mt19937 rng(dev());
	uniform_int_distribution<mt19937::result_type> dist(1, 100);
	
	int chanceToMultiplay = dist(rng);
	if (chanceToMultiplay > 92) {
		nextPositionStruct nextPosition_;
		if (nextPosition(nextPosition_, mapArray)) {
			string actionLog;
			organismVector.push_back(getClass());
			organismVector.back()->setPositionX(nextPosition_.positionX);
			organismVector.back()->setPositionY(nextPosition_.positionY);
			organismVector.back()->setIsAlive(true);
			organismVector.back()->setDidMove(true);
			actionLog =
				+"A "
				+ getName()
				+ " has grown at ("
				+ std::to_string(nextPosition_.positionX + 1)
				+ ","
				+ std::to_string(nextPosition_.positionY + 1)
				+ ")";
			worldReference.addToTurnLog(actionLog);
		}
	}
	setAge(age + 1);
}

bool Plant::nextPosition(nextPositionStruct& nextPosition_, Organism* mapArray[20][20])
{
	/*
			|7|8|1|  
			|6|X|2|   <- Functions checks in this order if there is an empty field around the plant
			|5|4|3|   
	*/
	nextPosition_.positionX = getPositionX();
	nextPosition_.positionY = getPositionY();

	nextPosition_.positionX += 1;
	nextPosition_.positionY += 1;
	if (positionsCheck(nextPosition_, mapArray)) return true;

	nextPosition_.positionY +=1;
	if (positionsCheck(nextPosition_, mapArray)) return true;

	nextPosition_.positionY += 1;
	if (positionsCheck(nextPosition_, mapArray)) return true;

	nextPosition_.positionX -= 1;
	if (positionsCheck(nextPosition_, mapArray)) return true;

	nextPosition_.positionX -= 1;
	if (positionsCheck(nextPosition_, mapArray)) return true;

	nextPosition_.positionY -= 1;
	if (positionsCheck(nextPosition_, mapArray)) return true;

	nextPosition_.positionY -= 1;
	if (positionsCheck(nextPosition_, mapArray)) return true;

	nextPosition_.positionX += 1;
	if (positionsCheck(nextPosition_, mapArray)) return true;

	return false;
} 
bool Plant::positionsCheck(nextPositionStruct& nextPosition_, Organism* mapArray[20][20]) {

	if (nextPosition_.positionX >= 0 && nextPosition_.positionX <= 19 && nextPosition_.positionY >= 0 && nextPosition_.positionY <= 19
		&& mapArray[nextPosition_.positionX][nextPosition_.positionY] == nullptr) return true;
	return false;
}

void Plant::collision()
{

}

Plant::~Plant()
{
}
