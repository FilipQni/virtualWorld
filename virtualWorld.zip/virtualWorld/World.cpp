#include "World.h"

World::World()
{
}

void World::takeTurn()
{
	clearTurnLog();
	sortVector();
	makeArrayFromVector();
	for (int i = 0; i < organismVector.size(); i++) {
		organismVector[i]->setDidMove(false);
	}

	for (int i = 0; i < organismVector.size(); i++) {
		if (organismVector[i]->getIsAlive() && !organismVector[i]->getDidMove()) {
			if (organismVector[i]->getExtraMove()) {
				organismVector[i]->action(mapArray, organismVector, i);
				organismVector[i]->setExtraMove(false);
			}
			organismVector[i]->action(mapArray, organismVector, i);
			makeArrayFromVector();
		}
	}
	sortVector();
}

void World::drawWorld()
{
	cout << " ";
	for (int i = 0; i < 20; i++) {
		cout << '-';
	}
	cout << '\n';
	for (int i = 0; i < 20; i++) {
		cout << '|';
		for (int j = 0; j < 20; j++) {
			if (mapArray[j][i] != nullptr) cout << mapArray[j][i]->getSymbol();
			else cout << ' ';
		}
		cout << '|';
		cout << endl;
	}

	cout << " ";
	for (int i = 0; i < 20; i++) {
		cout << '-';
	}

}

void World::makeArrayFromFile(World& worldReference, string fileName)
{
	ifstream file(fileName.c_str());
	if (!file.good()) {
		cout << "LOADING FILE - FAIL\n";
	}
	
	char orgChar;
	int orgPositionX;
	int orgPositionY;
	int box;
	bool boxBool;

	Organism* organismBox = nullptr;

	for (int i = 0; i < 20; i++) {
		for (int j = 0; j < 20; j++) {
			mapArray[i][j] = nullptr;
		}
	}
	organismVector.clear();
	while (!file.eof()) {
		file >> orgChar;
		switch (orgChar)
		{
		case 'W':
			organismBox = new Wolf(worldReference);
			cout << "wilk" << endl;
			break;
		case 'S':
			organismBox = new Sheep(worldReference);
			cout << "owca" << endl;
			break;
		case 'F':
			organismBox = new Fox(worldReference);
			cout << "Lis" << endl;
			break;
		case '$':
			organismBox = new Sloth(worldReference);
			break;
		case 'D':
			organismBox = new Dog(worldReference);
			break;
		case '#':
			organismBox = new Grass(worldReference);
			break;
		case 'C':
			organismBox = new Coca(worldReference);
			break;
		case 'G':
			organismBox = new Guarana(worldReference);
			break;
		default:
			cout << "co sie dzieje\n";
			break;
		}
		file >> orgPositionX;
		organismBox->setPositionX(orgPositionX);

		file >> orgPositionY;
		organismBox->setPositionY(orgPositionY);

		file >> box;
		organismBox->setAge(box);

		file >> box;
		organismBox->setStrength(box);

		file >> boxBool;
		organismBox->setExtraMove(boxBool);

		organismVector.push_back(organismBox);
		mapArray[orgPositionX][orgPositionY] = organismVector.back();

		/* loading from file in order:
		1 positionX 
		2 positionY
		3 age
		4 strength
		5 extraMove
		*/
	}
	file.close();
}

void World::saveGame(string fileName)
{
	ofstream file;
	file.open(fileName, ios::trunc | ios::out);

	for (int i = 0; i < organismVector.size(); i++)
	{
		file << organismVector[i]->getSymbol() << ' ' << organismVector[i]->getPositionX() << ' ' << organismVector[i]->getPositionY() << ' ' 
			<< organismVector[i]->getAge() << ' ' << organismVector[i]->getStrength() << ' ' << organismVector[i]->getExtraMove() << '\n';
	}
	file.close();
}

void World::makeArrayFromVector()
{
	int x;
	int y;
	for (int i = 0; i < 20; i++) {
		for (int j = 0; j < 20; j++) {
			mapArray[i][j] = nullptr;
		}
	}

	for (int i = 0; i < organismVector.size(); i++) {
		if (organismVector[i]->getIsAlive()) {
			x = organismVector[i]->getPositionX();
			y = organismVector[i]->getPositionY();
			mapArray[x][y] = organismVector[i];
		}
	}
}

void World::sortVector()
{	
	for (int i = 0; i < organismVector.size(); i++) {
		if (!organismVector[i]->getIsAlive()) {
			organismVector.erase(organismVector.begin() + i);
		}
	}
	int n = organismVector.size();
	for (int i = 0; i < n - 1; i++) {
		for (int j = 0; j < n - 1 - i; j++) {
			if (organismVector[j]->getAgility() < organismVector[j + 1]->getAgility()) swap(organismVector[j], organismVector[j + 1]);
			if (organismVector[j]->getAgility() == organismVector[j + 1]->getAgility()) {
				if (organismVector[j]->getAge() < organismVector[j + 1]->getAge()) swap(organismVector[j], organismVector[j + 1]);
			}
		}
	}
}

vector<Organism*> World::getOrganismVector()
{
	return organismVector;
}

void World::addToTurnLog(string actionData)
{
	turnLog.push_back(actionData);
}

vector<string> World::getTurnLog()
{
	return turnLog;
}

void World::clearTurnLog()
{
	turnLog.clear();
}

World::~World()
{
}
